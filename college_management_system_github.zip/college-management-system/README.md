# College Management System (Python)

A menu-driven college administration project built using Python's standard library. It runs in the terminal and stores records in JSON files.

## Features

- Register, view, search, update, and delete students
- Record and view attendance
- Record fee payments and calculate outstanding balances
- Persist data between runs using JSON files
- Validate common inputs such as duplicate student IDs, dates, and payment amounts

## Requirements

- Python 3.9 or newer recommended
- Visual Studio Code (optional, but convenient)
- No third-party Python packages required

## Run on Windows

1. Download or clone this repository.
2. Open the project folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Check Python:

   ```powershell
   python --version
   ```

   If needed, use `py --version`.

5. Run the application from the project directory:

   ```powershell
   python main.py
   ```

   Or:

   ```powershell
   py main.py
   ```

## Project structure

```text
college-management-system/
├── main.py
├── storage.py
├── student_manager.py
├── attendance_manager.py
├── fee_manager.py
├── README.md
├── .gitignore
└── data/                  # Created automatically at runtime
    ├── students.json
    ├── attendance.json
    └── payments.json
```

## First test

1. Choose `1` to register a student.
2. Enter a sample ID such as `STU101`, a name, department, phone, and total fee.
3. Choose `2` to view students.
4. Choose `6` to mark attendance.
5. Choose `8` to record a fee payment.
6. Choose `9` to view the fee report.
7. Exit and run the application again to verify that data persists.

Use fictional sample data when taking screenshots or sharing the repository publicly. This is an educational starter project, not a production system for sensitive student records.

## Upload to GitHub

Create an empty repository on GitHub, then run these commands in the project folder. Replace the URL with your repository URL:

```powershell
git init
git add .
git commit -m "Add Python College Management System"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/college-management-system.git
git push -u origin main
```

Git must be installed and configured, and you must authenticate with GitHub when prompted.

## Concepts demonstrated

- Functions and modules
- Lists and dictionaries
- Loops and conditional statements
- Input validation and exception handling
- JSON file storage
- `pathlib` and `datetime`
