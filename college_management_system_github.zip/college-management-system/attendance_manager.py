from datetime import date
from storage import load_data, save_data
from student_manager import find_student

FILE = "attendance.json"


def mark_attendance():
    student_id = input("Enter student ID: ").strip()
    student = find_student(student_id)
    if not student:
        print("Student not found. Register the student first.")
        return

    attendance_date = input(f"Date (YYYY-MM-DD) [{date.today()}]: ").strip()
    if not attendance_date:
        attendance_date = str(date.today())

    try:
        date.fromisoformat(attendance_date)
    except ValueError:
        print("Invalid date. Use YYYY-MM-DD.")
        return

    status = input("Attendance (P = Present, A = Absent): ").strip().upper()
    if status not in ("P", "A"):
        print("Enter P or A.")
        return

    records = load_data(FILE)
    for record in records:
        if record["student_id"] == student_id and record["date"] == attendance_date:
            record["status"] = status
            save_data(FILE, records)
            print("Attendance updated.")
            return

    records.append({
        "student_id": student_id,
        "name": student["name"],
        "date": attendance_date,
        "status": status,
    })
    save_data(FILE, records)
    print("Attendance saved.")


def view_attendance():
    records = load_data(FILE)
    student_id = input("Enter student ID (leave blank for all): ").strip()
    selected = [
        record for record in records
        if not student_id or record["student_id"] == student_id
    ]

    if not selected:
        print("No attendance records found.")
        return

    for record in selected:
        print(
            f"{record['date']} | {record['student_id']} | "
            f"{record['name']} | {record['status']}"
        )

    present = sum(record["status"] == "P" for record in selected)
    absent = sum(record["status"] == "A" for record in selected)
    total = present + absent
    print(f"Present: {present}")
    print(f"Absent: {absent}")
    if total:
        print(f"Attendance percentage: {present / total * 100:.2f}%")
