from storage import load_data, save_data
from student_manager import find_student

FILE = "payments.json"


def record_payment():
    student_id = input("Enter student ID: ").strip()
    student = find_student(student_id)
    if not student:
        print("Student not found. Register the student first.")
        return

    payments = load_data(FILE)
    paid_so_far = sum(
        payment["amount"] for payment in payments
        if payment["student_id"] == student_id
    )
    total_fee = student["total_fee"]
    balance = total_fee - paid_so_far

    print(f"Total fee: Rs. {total_fee:.2f}")
    print(f"Already paid: Rs. {paid_so_far:.2f}")
    print(f"Remaining balance: Rs. {balance:.2f}")

    if balance <= 0:
        print("The student's fees are fully paid.")
        return

    try:
        amount = float(input("Enter payment amount: "))
        if amount <= 0 or amount > balance:
            print("Payment must be positive and cannot exceed the balance.")
            return
    except ValueError:
        print("Enter a valid numeric amount.")
        return

    payments.append({
        "student_id": student_id,
        "name": student["name"],
        "amount": amount,
    })
    save_data(FILE, payments)
    print(f"Payment of Rs. {amount:.2f} recorded successfully.")


def fee_report():
    students = load_data("students.json")
    payments = load_data(FILE)
    if not students:
        print("No students registered.")
        return

    print("\n--- COLLEGE FEE REPORT ---")
    for student in students:
        student_id = student["student_id"]
        total_fee = student["total_fee"]
        paid = sum(
            payment["amount"] for payment in payments
            if payment["student_id"] == student_id
        )
        balance = total_fee - paid
        print(f"\nStudent: {student['name']} ({student_id})")
        print(f"Total fee: Rs. {total_fee:.2f}")
        print(f"Paid: Rs. {paid:.2f}")
        print(f"Balance: Rs. {balance:.2f}")
