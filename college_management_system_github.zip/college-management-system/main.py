from student_manager import (
    add_student, view_students, search_student, update_student, delete_student
)
from attendance_manager import mark_attendance, view_attendance
from fee_manager import record_payment, fee_report


def display_menu():
    print("\n" + "=" * 42)
    print("       COLLEGE MANAGEMENT SYSTEM")
    print("=" * 42)
    print("1. Register student")
    print("2. View all students")
    print("3. Search student")
    print("4. Update student")
    print("5. Delete student")
    print("6. Mark attendance")
    print("7. View attendance")
    print("8. Record fee payment")
    print("9. View fee report")
    print("0. Exit")
    print("=" * 42)


def main():
    actions = {
        "1": add_student,
        "2": view_students,
        "3": search_student,
        "4": update_student,
        "5": delete_student,
        "6": mark_attendance,
        "7": view_attendance,
        "8": record_payment,
        "9": fee_report,
    }

    while True:
        display_menu()
        choice = input("Enter your choice: ").strip()

        if choice == "0":
            print("Thank you for using College Management System!")
            break

        action = actions.get(choice)
        if action:
            try:
                action()
            except (OSError, KeyError, TypeError) as error:
                print(f"An error occurred: {error}")
        else:
            print("Invalid choice. Please select a number from 0 to 9.")


if __name__ == "__main__":
    main()
