from storage import load_data, save_data

FILE = "students.json"


def get_students():
    return load_data(FILE)


def find_student(student_id):
    for student in get_students():
        if student["student_id"] == student_id:
            return student
    return None


def add_student():
    students = get_students()
    student_id = input("Enter student ID: ").strip()

    if not student_id:
        print("Student ID cannot be empty.")
        return
    if any(s["student_id"] == student_id for s in students):
        print("This student ID already exists.")
        return

    name = input("Enter student name: ").strip()
    department = input("Enter department: ").strip()
    phone = input("Enter phone number: ").strip()
    if not name or not department:
        print("Name and department are required.")
        return

    try:
        total_fee = float(input("Enter total college fee: "))
        if total_fee < 0:
            raise ValueError
    except ValueError:
        print("Enter a valid, non-negative fee.")
        return

    students.append({
        "student_id": student_id,
        "name": name,
        "department": department,
        "phone": phone,
        "total_fee": total_fee,
    })
    save_data(FILE, students)
    print("Student registered successfully.")


def view_students():
    students = get_students()
    if not students:
        print("No student records found.")
        return

    for student in students:
        print("-" * 35)
        print("ID:", student["student_id"])
        print("Name:", student["name"])
        print("Department:", student["department"])
        print("Phone:", student["phone"])
        print("Total fee:", student["total_fee"])


def search_student():
    student_id = input("Enter student ID to search: ").strip()
    student = find_student(student_id)
    if student:
        for key, value in student.items():
            print(f"{key.replace('_', ' ').title()}: {value}")
    else:
        print("Student not found.")


def update_student():
    students = get_students()
    student_id = input("Enter student ID to update: ").strip()
    student = next((s for s in students if s["student_id"] == student_id), None)

    if not student:
        print("Student not found.")
        return

    name = input(f"Name [{student['name']}]: ").strip()
    department = input(f"Department [{student['department']}]: ").strip()
    phone = input(f"Phone [{student['phone']}]: ").strip()

    if name:
        student["name"] = name
    if department:
        student["department"] = department
    if phone:
        student["phone"] = phone

    save_data(FILE, students)
    print("Student details updated.")


def delete_student():
    students = get_students()
    student_id = input("Enter student ID to delete: ").strip()
    student = next((s for s in students if s["student_id"] == student_id), None)

    if not student:
        print("Student not found.")
        return

    confirm = input(f"Delete {student['name']}? Type YES to confirm: ").strip()
    if confirm == "YES":
        students.remove(student)
        save_data(FILE, students)
        print("Student deleted.")
        print("Note: Existing attendance and payment records are retained.")
    else:
        print("Deletion cancelled.")
